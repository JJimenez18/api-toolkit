import { performance } from 'perf_hooks';
import { parseString } from 'xml2js';
import { LoggerS3, TraceId } from '../middlewares';

export class Utilerias {
  static generarFolio = (): string => {
    const fecha = new Date();
    const numeroMes = fecha.getMonth() + 1;
    const mes = numeroMes < 10 ? `0${numeroMes}` : numeroMes;
    const dia = fecha.getDate() < 10 ? `0${fecha.getDate()}` : fecha.getDate();
    const hora = fecha.getHours() < 10 ? `0${fecha.getHours()}` : fecha.getHours();
    const minuto = fecha.getMinutes() < 10 ? `0${fecha.getMinutes()}` : fecha.getMinutes();
    const segundo = fecha.getSeconds() < 10 ? `0${fecha.getSeconds()}` : fecha.getSeconds();
    // eslint-disable-next-line max-len
    return TraceId.obtenerTraceId() || `${fecha.getFullYear()}${mes}${dia}${hora}${minuto}${segundo}${fecha.getMilliseconds()}`;
  }

  /**
   * Función que concatena una lista de cadenas.
   * @param cadenas Lista de cadenas a unir.
   * @returns Devuelve una cadena producto de la concatenación.
   */
  static unaLinea = (...cadenas: string[]): string => cadenas
    .reduce((anterior, siguiente) => `${anterior || ''}${siguiente}`);

  /**
  * Función que agrega ceros a la izquierda.
  * @param cadena Cadena que se modificará.
  * @param longitud Número que indica la longitud final que tendrá la cadena.
  * @returns Devuelve la cadena con los ceros correspondientes.
  * Si la cadena original es mayor que el parámetro longitud, se devuelve la cadena original.
  * Ejemplo: cadena --> 1234, longitud --> 6, resultado: 001234
  */
  static agregarCerosIzq = (cadena: string, longitud: number): string => {
    const cad = `${cadena}`;
    if (!cad || cad.trim() === '') return cad;
    const cerosFaltantes = longitud - cad.length;
    if (cerosFaltantes <= 0) return cad;
    /* let ceros = '';
    for (let i = 0; i < cerosFaltantes; i += 1) {
      ceros += '0';
    } */
    const cero = '0';
    return `${cero.repeat(cerosFaltantes)}${cad}`;
  };

  /**
  * Función que elimina los ceros a la izquierda (o cualquier caracter que no sea un número del 1 al 9) de una cadena.
  * @param cadena cadena que se va a modificar.
  * @param longitudMinima (opcional) longitud mínima que debe tener la cadena resultante.
  * Este campo solo es útil cuando solo se quieren quitar algunos ceros.
  * @returns Devuelve la cadena sin ceros a la izquierda.
  * Ejemplos:
  *  Caso 1: No se establece una longitudMinima.
  *    - cadena: GS0001234, resultado: 1234
  *  Caso 2: Se establece una longitudMinima. La longitud mínima es mayor que la longitud de la cadena sin ceros.
  *    - cadena: GS0001234, longitudMinima: 5 resultado: 01234
  *  Caso 3: Se establece una longitdMinima. La longitud mínima es menor o igual que la longitud de la cadena sin ceros.
  *  La longitud mínima SE IGNORA.
  *    - cadena: GS0001234, longitudMinima: 3 resultado: 1234
  */
  static quitarCerosIzq = (cadena: string, longitudMinima?: number): string => {
    const cad = `${cadena}`;
    if (!cad || cad.trim() === '') return cad;
    const primerNumeroNoCero = cad.search(/[1-9]/);
    if (longitudMinima && (cad.length - primerNumeroNoCero) < longitudMinima) {
      return cad.substring(cad.length - longitudMinima);
    }
    return cad.substring(primerNumeroNoCero);
  };

  /**
  * Función que elimina de la cadena original cualquier caracter que no sea un número.
  * @param cadena Cadena que se va a modificar.
  * @returns Devuelve la cadena únicamente con números.
  */
  static soloNumeros = (cadena: string): string => {
    const cad = `${cadena}`;
    return cad.replace(/\D/g, '');
  };

  /**
  * Función que recorta una cadena a la longitud solicitada.
  * @param cadena Cadena que se va a modificar.
  * @param longitud Longitud de la cadena resultante.
  * @returns Devuelve una cadena con la longitud solicitada.
  * Ejemplos:
  *  Caso 1: Si la longitud es menor o igual que la longitud de la cadena original, se ejecuta la operación.
  *   - cadena: 0123456789, longitud: 5, resultado: 56789
  *  Case 2: Si la longitud es mayor que la cadena original, se devuelve la cadena original.
  */
  static recortarCadena = (cadena: string, longitud: number): string => {
    if (cadena.length <= longitud) return cadena;
    return cadena.substring(cadena.length - longitud);
  };

  static isBase64 = (str: any) => {
    if (typeof str !== 'string' || str.length % 4 !== 0) {
      return false;
    }
    const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
    return base64Regex.test(str);
  };
  static processObject = (objetoCopy: any) => {
    const obj = JSON.parse(JSON.stringify(objetoCopy));
    
    Object.keys(obj).forEach(key => {
      const value = obj[key];
      if (typeof value === 'string' && this.isBase64(value)) {
        obj[key] = 'trucado';
      } else if (typeof value === 'object' && value !== null) {
        this.processObject(value);
      }
    });
    return obj;
  };

  static objetoSinArrays(obj: any) {
    if (typeof obj !== 'object') {
      return true;
    }
    for (var prop in obj) {
      if (Array.isArray(obj[prop])) {
        return false; // Si encuentra un array, devuelve falso
      }
    }
    return true; // Si no encuentra ningún array, devuelve verdadero
  }
  static calcularTiempoEjecucion = (param: {
    inicio: number
    final?: number
  }) => Math.trunc(param.final ? (param.final - param.inicio) : performance.now() - param.inicio)
}

export const parseXmlToJson = async (xml: any): Promise<any> =>
  new Promise((resolve, reject) => {
    parseString(xml, (err, result) => {
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });

export const overrideConsole = () => {
    const logger = LoggerS3.getInstance().getLogger();
    const originalLog = console.log;

    console.log = (...args: any[]) => {
        const mensaje = args
            .map((arg) => (typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg))
            .join(' ');

        logger.info(mensaje);

        // originalLog.apply(console, args);
    };

    console.error = (...args: any[]) => {
        const mensaje = args
            .map((arg) => (typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg))
            .join(' ');
        logger.error(mensaje);
    };

    console.debug = (...args: any[]) => {
        const mensaje = args
            .map((arg) => (typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg))
            .join(' ');
        logger.debug(mensaje);
    };
};



/**
 * Elimina ceros a la izquierda de una placa o serie.
 */
export const formatearPlacaSerie = (palabra: string): string => {
    let palabraFormat = '';
    let avanzar = false;

    for (const letra of palabra) {
        if (letra !== '0') {
            avanzar = true;
        }
        if (avanzar) {
            palabraFormat += letra;
        }
    }
    return palabraFormat.trim();
};

/**
 * Si es un número entero, le agrega ceros a la izquierda hasta completar 18 caracteres.
 */
export const formatearNumeroDeSerie = (serie: string | number): string => {
    if (Number.isInteger(Number(serie))) {
        return String(serie).padStart(18, '0');
    }
    return String(serie).trim();
};

/**
 * Convierte a minúsculas, elimina ceros a la izquierda y espacios.
 */
export const formatearCadena = (cadena: string | number): string => {
    return String(cadena)
        .toLowerCase()
        .trim()
        .replace(/^0+/, '') // Simplificado sin el grupo de captura ( )
        .trim();
};

/**
 * Compara dos cadenas tras aplicar el formateo estándar.
 */
export const compararCadenas = (cadena1: string | number, cadena2: string | number): boolean => {
    return formatearCadena(cadena1) === formatearCadena(cadena2);
};

export const fechaYYYMMDD = (fecha: Date): string => {
  const anio = `${fecha.getFullYear()}`;
  const mes = `${fecha.getMonth() + 1}`.padStart(2, '0');
  const dia = `${fecha.getDate()}`.padStart(2, '0');
  // console.log(`${anio}-${mes}-${dia}`);
  return `${anio}-${mes}-${dia}`;
};

/**
 * Convierte minutos a segundos para su uso en JWT (exp) o Cache (TTL).
 * @param minutes - Cantidad de minutos a convertir.
 * @returns Cantidad equivalente en segundos.
 */
export const convertMinutesToSeconds = (minutes: number): number => {
  if (minutes < 0) {
    throw new Error('El tiempo no puede ser negativo');
  }
  return Math.floor(minutes * 60);
};

export const fechaDDMMAA = (
  fecha: Date,
  separador?: string,
): string => {
  const signo = separador || '/';
  const dia = `${fecha.getDate()}`.padStart(2, '0');
  const mes = `${fecha.getMonth() + 1}`.padStart(2, '0');
  const anio = fecha.getFullYear();
  return `${dia}${signo}${mes}${signo}${anio}`;
};

export const fechaDDMMAAHHMM = (
  fecha: Date,
): string => {
  const dia = `${fecha.getDate()}`.padStart(2, '0');
  const mes = `${fecha.getMonth() + 1}`.padStart(2, '0');
  const anio = fecha.getFullYear();
  const horas = `${fecha.getHours()}`.padStart(2, '0');
  const minutos = `${fecha.getMinutes()}`.padStart(2, '0');
  return `${dia}${mes}${anio}${horas}${minutos}`;
};

export const camalize = (cadena: string): string => cadena.replace(
  /\w\S*/g,
  (txt) => txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase(),
);

export const esPar = (
  numero: number | string,
): boolean => {
  if (typeof numero !== 'number') {
    // console.log('Debes ingresar un numero');
    return false;
  }
  if (numero % 2 === 0) {
    // console.log(`El numero ${numero} es Par`);
    return true;
  }
  // console.log(`El numero ${numero} es Impar`);
  return false;
};
